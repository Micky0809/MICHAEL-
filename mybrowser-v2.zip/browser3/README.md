# MyBrowser — Full-Featured Personal Android Browser

A complete personal browser built with Android WebView + Kotlin, featuring tabs, bookmarks, ad blocking, incognito mode, and downloads.

---

## Features

| Feature         | Details |
|-----------------|---------|
| **Tabs**        | Open multiple tabs, switch between them, close individually |
| **Incognito**   | No cookies, no cache, no storage saved — cleared on pause |
| **Bookmarks**   | Save/view/delete bookmarks with persistent storage |
| **Ad Blocker**  | Blocks 40+ known ad/tracker domains, toggleable from menu |
| **Downloads**   | Downloads files via Android DownloadManager to Downloads folder |
| **Smart URL bar** | Auto-detects URL vs search query |
| **Pull to refresh** | Swipe down to reload |
| **Desktop mode** | Toggle desktop user-agent from menu |
| **Share page**  | Share current URL via Android share sheet |

---

## Setup in Android Studio

1. Open Android Studio → **Open Existing Project** → select this folder
2. Wait for Gradle sync to complete
3. Add vector icons via **Right-click res → New → Vector Asset** (use built-in Material icons):
   - `ic_arrow_back`
   - `ic_arrow_forward`
   - `ic_refresh`
   - `ic_home`
   - `ic_tabs` (use `ic_tab` or `ic_layers`)
   - `ic_more_vert`
   - `ic_close`
   - `ic_delete`
4. Run on your Android device (minSdk 24 = Android 7.0+)

---

## Project Structure

```
app/src/main/
├── java/com/personal/browser/
│   ├── MainActivity.kt               ← Core browser + all feature wiring
│   ├── adapters/
│   │   ├── TabAdapter.kt             ← RecyclerView for tabs list
│   │   └── BookmarkAdapter.kt        ← RecyclerView for bookmarks list
│   ├── managers/
│   │   ├── BookmarkManager.kt        ← SharedPreferences persistence
│   │   ├── AdBlocker.kt              ← Domain blocklist engine
│   │   └── DownloadHandler.kt        ← DownloadManager wrapper
│   └── models/
│       └── Models.kt                 ← Tab + Bookmark data classes
├── res/
│   ├── layout/
│   │   ├── activity_main.xml
│   │   ├── sheet_tabs.xml
│   │   ├── sheet_menu.xml
│   │   ├── sheet_bookmarks.xml
│   │   ├── item_tab.xml
│   │   └── item_bookmark.xml
│   └── values/
│       ├── colors.xml
│       ├── strings.xml
│       └── themes.xml
└── AndroidManifest.xml
```

---

## How Each Feature Works

### Tabs
- Each `Tab` object stores URL, title, incognito flag, and saved WebView state
- Switching tabs saves/restores WebView state via `Bundle`
- Count badge on bottom bar shows number of open tabs

### Incognito Mode
- Disables cookies, DOM storage, form/password saving
- Sets cache mode to `LOAD_NO_CACHE`
- Clears WebStorage on page load and on app pause
- Marked with purple dot in URL bar and tab list

### Ad Blocker
- Intercepts all WebView resource requests via `shouldInterceptRequest`
- Matches request host against 40+ blocked ad/tracker domains
- Returns empty 204 response for blocked domains
- Toggle ON/OFF from the menu (persists per session)

### Bookmarks
- Stored as JSON in `SharedPreferences`
- Deduplicated by URL (re-bookmarking updates position)
- Sorted by most recently added

### Downloads
- Uses Android's built-in `DownloadManager`
- Saves to public Downloads folder
- Shows system notification when complete
