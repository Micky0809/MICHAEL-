package com.personal.browser.managers

import android.content.Context

class StartPageManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("startpage", Context.MODE_PRIVATE)

    var customUrl: String
        get() = prefs.getString("custom_url", "") ?: ""
        set(value) = prefs.edit().putString("custom_url", value).apply()

    var useCustomUrl: Boolean
        get() = prefs.getBoolean("use_custom_url", false)
        set(value) = prefs.edit().putBoolean("use_custom_url", value).apply()

    var wallpaperColor: String
        get() = prefs.getString("wallpaper_color", "#0F1117") ?: "#0F1117"
        set(value) = prefs.edit().putString("wallpaper_color", value).apply()

    var greeting: String
        get() = prefs.getString("greeting", "Hello!") ?: "Hello!"
        set(value) = prefs.edit().putString("greeting", value).apply()

    fun getStartUrl(): String {
        return if (useCustomUrl && customUrl.isNotBlank()) customUrl
        else "about:blank" // will be replaced by start page HTML
    }

    fun getStartPageHtml(bookmarks: List<Pair<String, String>>): String {
        val color = wallpaperColor
        val greet = greeting
        val bookmarkHtml = bookmarks.take(8).joinToString("") { (title, url) ->
            val shortTitle = if (title.length > 12) title.take(12) + "…" else title
            val domain = try { java.net.URL(url).host.removePrefix("www.") } catch (e: Exception) { title }
            """
            <a href="$url" class="bookmark">
                <div class="bk-icon">${domain.first().uppercaseChar()}</div>
                <span>$shortTitle</span>
            </a>
            """.trimIndent()
        }

        return """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    background: $color;
    font-family: -apple-system, sans-serif;
    color: #eaeaea;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 60px 20px 40px;
  }
  .greeting {
    font-size: 28px;
    font-weight: 600;
    margin-bottom: 8px;
    text-align: center;
  }
  .date {
    font-size: 14px;
    color: #888;
    margin-bottom: 48px;
    text-align: center;
  }
  .search-box {
    width: 100%;
    max-width: 480px;
    background: #1e2130;
    border-radius: 30px;
    padding: 14px 24px;
    font-size: 16px;
    color: #eaeaea;
    border: 1px solid #2a2e40;
    outline: none;
    margin-bottom: 48px;
    -webkit-appearance: none;
  }
  .search-box::placeholder { color: #555; }
  .section-title {
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: #555;
    margin-bottom: 16px;
    align-self: flex-start;
    max-width: 480px;
    width: 100%;
  }
  .bookmarks {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    width: 100%;
    max-width: 480px;
    margin-bottom: 40px;
  }
  .bookmark {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: #ccc;
    font-size: 11px;
    text-align: center;
  }
  .bk-icon {
    width: 52px;
    height: 52px;
    border-radius: 14px;
    background: #1e2130;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    font-weight: bold;
    color: #4F8EF7;
    border: 1px solid #2a2e40;
  }
  .empty-msg {
    color: #444;
    font-size: 13px;
    text-align: center;
    margin-top: 8px;
  }
</style>
</head>
<body>
<div class="greeting">$greet</div>
<div class="date" id="dateEl"></div>
<input class="search-box" type="text" placeholder="Search or enter URL…"
  onkeydown="if(event.key==='Enter'){var v=this.value.trim();if(!v)return;window.location.href=v.includes('.')?'https://'+v:'https://www.google.com/search?q='+encodeURIComponent(v);}">
${if (bookmarkHtml.isNotBlank()) """
<div class="section-title">Bookmarks</div>
<div class="bookmarks">$bookmarkHtml</div>
""" else """<div class="empty-msg">Save bookmarks to see them here</div>"""}
<script>
  var d = new Date();
  var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('dateEl').textContent = days[d.getDay()] + ', ' + months[d.getMonth()] + ' ' + d.getDate();
</script>
</body>
</html>
        """.trimIndent()
    }
}
