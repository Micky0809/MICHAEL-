package com.personal.browser.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.personal.browser.R
import com.personal.browser.models.Tab

class TabAdapter(
    private val tabs: List<Tab>,
    private val currentIndex: Int,
    private val onTabClick: (Int) -> Unit,
    private val onTabClose: (Int) -> Unit
) : RecyclerView.Adapter<TabAdapter.TabViewHolder>() {

    inner class TabViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView     = view.findViewById(R.id.tabTitle)
        val url: TextView       = view.findViewById(R.id.tabUrl)
        val close: ImageButton  = view.findViewById(R.id.tabClose)
        val incogIcon: View     = view.findViewById(R.id.tabIncogIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false)
        return TabViewHolder(view)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        val tab = tabs[position]
        holder.title.text = tab.title.ifBlank { "New Tab" }
        holder.url.text   = tab.url
        holder.incogIcon.visibility = if (tab.isIncognito) View.VISIBLE else View.GONE
        holder.itemView.isSelected  = position == currentIndex
        holder.itemView.alpha       = if (position == currentIndex) 1.0f else 0.75f
        holder.itemView.setOnClickListener { onTabClick(position) }
        holder.close.setOnClickListener   { onTabClose(position) }
    }

    override fun getItemCount() = tabs.size
}
