package com.personal.browser.managers

import android.content.Context
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

class AdBlocker(private val context: Context) {

    var isEnabled: Boolean = true

    // Common ad/tracker domains to block
    private val blockedDomains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com",
        "ads.yahoo.com", "advertising.com", "adtech.de",
        "amazon-adsystem.com", "media.net", "outbrain.com",
        "taboola.com", "revcontent.com", "mgid.com",
        "popads.net", "popcash.net", "propellerads.com",
        "adskeeper.co.uk", "bidvertiser.com", "clicksor.com",
        "contentabc.com", "exoclick.com", "trafficjunky.net",
        "adsrvr.org", "rubiconproject.com", "openx.net",
        "pubmatic.com", "appnexus.com", "criteo.com",
        "scorecardresearch.com", "quantserve.com", "chartbeat.com",
        "hotjar.com", "fullstory.com", "loggly.com",
        "facebook.com/tr", "connect.facebook.net",
        "platform.twitter.com", "syndication.twitter.com",
        "analytics.google.com", "google-analytics.com",
        "googletagmanager.com", "googletagservices.com",
        "clarity.ms", "mc.yandex.ru"
    )

    fun shouldBlock(host: String): Boolean {
        if (!isEnabled) return false
        return blockedDomains.any { blocked -> host.endsWith(blocked) || host == blocked }
    }

    fun emptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain", "utf-8", 204,
            "No Content", emptyMap(),
            ByteArrayInputStream(ByteArray(0))
        )
    }
}
